package net.riaspace.flerrydemo.models;

public class NotExistingVO
{
	
	protected String someString;
	
	public NotExistingVO()
	{
	}

	public String getSomeString()
	{
		return someString;
	}

	public void setSomeString(String someString)
	{
		this.someString = someString;
	}
}
