package com.erkobridee.util.interfaces;

import java.util.List;

/**
 * 
 * Interface que define os métodos padrão para serem implementados
 * nas classes DAO
 * 
 * @author Erko Bridee de Almeida Cabrera
 */
public interface BasicCRUDInterface<T> {

	/**
	 * Metodo para recuperar um objeto pelo seu ID
	 * 
	 * @param object T
	 * @return T
	 */
	public T get(T object);
	
	/**
	 * Metodo para salvar (inserir ou atualizar)
	 * um objeto
	 * 
	 * @param object T
	 */
	public void save(T object) throws Exception;
	
	/**
	 * Metodo para remover um determinado objeto
	 * 
	 * @param object T
	 */
	public void remove(T object);
	
	/**
	 * Metodo para recuperar a lista dos objetos cadastrados
	 * 
	 * @return List<T>
	 */
	public List<T> list();
	
}
