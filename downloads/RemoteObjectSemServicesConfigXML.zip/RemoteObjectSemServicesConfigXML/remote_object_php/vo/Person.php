<?php

class Person {
    
	var $firstName;
    var $lastName;
    var $phone;
    var $email;
    // explicit actionscript package
    var $_explicitType = "RO.teste.Person";
}

?>