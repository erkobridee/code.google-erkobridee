<?php

require_once "vo/Person.php";

class PersonService
{
    /**
     * Get a list of people
     * @returns An Array of Person
     */
    function getList()
    {
        $people = array(
            array("Alessandro", "Crugnola", "+390332730999", "alessandro@sephiroth.it"),
            array("Patrick", "Mineault", "+1234567890", "patrick@5etdemi.com"),
        );

        $p = array();

        for($a = 0; $a < count($people); $a++){
            $person = new Person();
            $person->firstName = $people[$a][0];
            $person->lastName = $people[$a][1];
            $person->phone = $people[$a][2];
            $person->email = $people[$a][3];
            $p[] = $person;
        }

        return $p;
    }
	
	function getPerson() {
		$person = new Person();
		$person->firstName = "Primeiro Nome";
		$person->lastName = "Sobre Nome";
		$person->phone = "+5533333333";
		$person->email = "mail@host.dom";
		
		return $person;
	}
}

?>