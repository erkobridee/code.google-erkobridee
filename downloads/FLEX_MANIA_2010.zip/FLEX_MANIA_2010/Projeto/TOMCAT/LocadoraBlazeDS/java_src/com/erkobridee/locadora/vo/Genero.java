package com.erkobridee.locadora.vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name="genero")
@NamedQueries( {
	// seleciona todos os generos
	@NamedQuery(name="genero.findAll", query = "from Genero"),
	// seleciona um determinado filme
	@NamedQuery(name="genero.byId", query = "select g from Genero g where g.id= :generoId")
})
public class Genero implements Serializable {
	//--------------------------------------------------------------------------
	private static final long serialVersionUID = 1L;
	//--------------------------------------------------------------------------
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id", nullable=false)	
	private Long id;
	
	@Index(name = "genero_idx_descricao")
	@Column(name="descricao", nullable=false, unique=true)
	private String descricao;
	//--------------------------------------------------------------------------
	/**
	 * Construtor sem parâmetros
	 */
	public Genero() {}
	//--------------------------------------------------------------------------
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
}
