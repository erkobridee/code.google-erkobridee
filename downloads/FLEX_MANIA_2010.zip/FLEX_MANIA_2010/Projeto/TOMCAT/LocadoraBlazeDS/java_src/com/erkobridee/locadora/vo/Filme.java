package com.erkobridee.locadora.vo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "filme")
@NamedQueries( {
	// seleciona todos os filmes
	@NamedQuery(name = "filme.findAll", query = "from Filme"),
	// seleciona um determinado filme
	@NamedQuery(name = "filme.byId", query = "select f from Filme f where f.id= :filmeId"),
	// seleciona todos os filmes de um determinado genero
	@NamedQuery(name = "filme.byGenero", query = "select f from Filme f where f.genero.id= :generoId"),
})
public class Filme implements Serializable {
	//--------------------------------------------------------------------------
	private static final long serialVersionUID = 1L;
	//--------------------------------------------------------------------------
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", nullable = false)	
	private Long id;
	
	@ManyToOne
	@JoinColumn(name="genero_id")
	private Genero genero;
	
	@Index(name = "filme_idx_titulo")
	@Column(name = "titulo", length=80, nullable = false, unique = true)
	private String titulo;
	
	@Index(name = "filme_idx_titulo_original")
	@Column(name = "titulo_original", length=80, nullable = false, unique = true)
	private String tituloOriginal;
	
	@Column(name = "lancamento")
	@Temporal(TemporalType.DATE)
	private Date lancamento;
	
	@Column(name = "pais_origem", length=80)
	private String paisOrigem;
	
	@Column(name = "duracao")
	private int duracao;
	
	@Column(name = "faixa_etaria")
	private int faixaEtaria;
	
	@Column(name = "sinopse")
	@Lob
	private String sinopse;
	
	@Column(name = "observacao")
	@Lob
	private String observacao;
	//--------------------------------------------------------------------------	
	/**
	 * Construtor se parâmetros
	 */
	public Filme() {}
	//--------------------------------------------------------------------------
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getTituloOriginal() {
		return tituloOriginal;
	}

	public void setTituloOriginal(String tituloOriginal) {
		this.tituloOriginal = tituloOriginal;
	}

	public Date getLancamento() {
		return lancamento;
	}

	public void setLancamento(Date lancamento) {
		this.lancamento = lancamento;
	}

	public String getPaisOrigem() {
		return paisOrigem;
	}

	public void setPaisOrigem(String paisOrigem) {
		this.paisOrigem = paisOrigem;
	}

	public int getDuracao() {
		return duracao;
	}

	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}

	public int getFaixaEtaria() {
		return faixaEtaria;
	}

	public void setFaixaEtaria(int faixaEtaria) {
		this.faixaEtaria = faixaEtaria;
	}

	public String getSinopse() {
		return sinopse;
	}

	public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	
	
}
