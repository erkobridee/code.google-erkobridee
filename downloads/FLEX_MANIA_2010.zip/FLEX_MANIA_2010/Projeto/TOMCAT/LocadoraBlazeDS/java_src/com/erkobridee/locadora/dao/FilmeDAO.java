package com.erkobridee.locadora.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.erkobridee.locadora.vo.Filme;
import com.erkobridee.util.interfaces.BasicCRUDInterface;

public class FilmeDAO extends BaseDAO implements BasicCRUDInterface<Filme> {
	//--------------------------------------------------------------------------
	// definição do logger
	private static Logger logger = Logger.getLogger(FilmeDAO.class);
	//--------------------------------------------------------------------------
	public FilmeDAO() {}
	//--------------------------------------------------------------------------
	public Filme get(Filme object) {
		logger.debug("method : get");
		
		// recupera a instância do gerenciador de entidades
		EntityManager em = super.getEntityManager();
		
		// verifica se é possível efetuar a consulta
		if( object != null && object.getId() != null ) {		
			object = em.find(Filme.class, object.getId());
		} else {
			object = null;
		}
		
		// retorna o objeto carregado
		return object;
	}

	@SuppressWarnings(value="unchecked")
	public List<Filme> list() {
		logger.debug("method : list");

		// recupera a instância do gerenciador de entidades
		EntityManager em = super.getEntityManager();
		
		Query findAllQuery = em.createNamedQuery("filme.findAll");
		List<Filme> filmes = findAllQuery.getResultList();

		if (filmes != null)
			logger.debug("** Found " + filmes.size() + " records");
		
		// retorna a lista de configurações cadastradas na base de dados
		return filmes;
	}
	
	@SuppressWarnings(value="unchecked")
	public List<Filme> listByGenero(Filme object) {
		logger.debug("method : listByGenero");

		// recupera a instância do gerenciador de entidades
		EntityManager em = super.getEntityManager();
		
		Query findAllQuery = em.createNamedQuery("filme.byGenero");
		findAllQuery.setParameter("generoId", object.getGenero().getId());
		List<Filme> filmes = findAllQuery.getResultList();

		if (filmes != null)
			logger.debug("** Found " + filmes.size() + " records");
		
		// retorna a lista de configurações cadastradas na base de dados
		return filmes;
	}

	public void remove(Filme object) {
		logger.debug("method : remove");

		// verifica se o objeto não é nulo
		if( object != null ) {
					
			// recupera a instância do gerenciador de entidades
			EntityManager em = super.getEntityManager();
			
			EntityTransaction tx = em.getTransaction();
			tx.begin();
			try {
				object = em.find(Filme.class, object.getId());				
				if( object != null ) {
					em.remove(object);
					tx.commit();
				}
			} catch (Exception e) {
				logger.error("Error: " + e.getMessage());
				tx.rollback();
			} finally {
				logger.info("Closing Entity Manager.");
				em.close();
			}
		}
	}

	public void save(Filme object) throws Exception {
		logger.debug("method : save");
		
		// recupera a instância do gerenciador de entidades
		EntityManager em = super.getEntityManager();
		
		// verificando a validade do id do objeto
		if( object != null && object.getId() == 0 ) {
			object.setId(null);
		}
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			em.merge(object);
			tx.commit();
		} catch (Exception e) {
			logger.error("Error: " + e.getMessage());
			tx.rollback();
			throw new Exception(e.getMessage());
		} finally {
			logger.info("Closing Entity Manager.");
			em.close();
		}
	}

}
