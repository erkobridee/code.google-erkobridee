package com.erkobridee.flexmania.helloblazeds.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Erko Bridee
 * @description
 * Classe que representa as informações trafegadas entre Flex e o Servidor
 *
 */
public class AppVO implements Serializable {

	//--------------------------------------------------------------------------
	private static final long serialVersionUID = 1L;
	//--------------------------------------------------------------------------
	
	private String message;
	private Date dtMessage;

	//--------------------------------------------------------------------------	
	public AppVO() {}
	//--------------------------------------------------------------------------
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getDtMessage() {
		return dtMessage;
	}

	public void setDtMessage(Date dtMessage) {
		this.dtMessage = dtMessage;
	}
	
	//--------------------------------------------------------------------------
	
	/**
	 * Método que retorna as informações do objeto
	 */
	public String toString() {
		String out = "";
		
		out += "message: " + this.getMessage();
		out += "\n";
		out += "date: " + this.getDtMessage();
		
		return out;
	}
}
