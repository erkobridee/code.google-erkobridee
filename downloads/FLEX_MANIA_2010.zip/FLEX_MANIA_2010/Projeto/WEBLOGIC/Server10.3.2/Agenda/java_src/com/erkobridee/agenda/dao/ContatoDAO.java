package com.erkobridee.agenda.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.erkobridee.agenda.vo.Contato;
import com.erkobridee.util.interfaces.BasicCRUDInterface;

/**
 * Classe que implementa o acesso aos dados
 * 
 * @author Erko Bridee
 *
 */
public class ContatoDAO extends BaseDAO implements BasicCRUDInterface<Contato> {

	//--------------------------------------------------------------------------
	// definição do logger
	private static Logger logger = Logger.getLogger(ContatoDAO.class);
	//--------------------------------------------------------------------------
	/**
	 * Metodo que retorna uma instancia da classe
	 * 
	 * @return ContatoDAO
	 */
	public static ContatoDAO getInstance() {
		return new ContatoDAO();
	}
	//--------------------------------------------------------------------------
	
	@Override
	public Contato get(Contato object) {
		logger.debug("method : get");
		
		EntityManager em = super.getEntityManager();
		
		if( object != null && object.getId() != null ) {		
			object = em.find(Contato.class, object.getId());
		} else {
			object = null;
		}
		
		return object;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Contato> list() {
		logger.debug("method : list");

		// recupera a instância do gerenciador de entidades
		EntityManager em = super.getEntityManager();
		
		Query findAllQuery = em.createNamedQuery("contato.findAll");
		List<Contato> contatos = findAllQuery.getResultList();

		if (contatos != null)
			logger.debug("** Found " + contatos.size() + " records");
		
		return contatos;
	}

	@Override
	public void remove(Contato object) {
		logger.debug("method : remove");

		if( object != null ) {					
			EntityManager em = super.getEntityManager();
			
			EntityTransaction tx = em.getTransaction();
			tx.begin();
			try {
				object = em.find(Contato.class, object.getId());				
				if( object != null ) {
					em.remove(object);
					tx.commit();
				}
			} catch (Exception e) {
				logger.error("Error: " + e.getMessage());
				tx.rollback();
			} finally {
				logger.info("Closing Entity Manager.");
				em.close();
			}
		}
	}

	@Override
	public void save(Contato object) throws Exception {
		logger.debug("method : save");
		
		EntityManager em = super.getEntityManager();

		if( object != null && object.getId() == 0 ) {
			object.setId(null);
		}
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			em.merge(object);
			tx.commit();
		} catch (Exception e) {
			logger.error("Error: " + e.getMessage());
			tx.rollback();
			throw new Exception(e.getMessage());
		} finally {
			logger.info("Closing Entity Manager.");
			em.close();
		}
	}

}
