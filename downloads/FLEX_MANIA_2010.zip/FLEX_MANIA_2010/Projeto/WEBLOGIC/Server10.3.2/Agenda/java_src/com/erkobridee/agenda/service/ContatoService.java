package com.erkobridee.agenda.service;

import java.util.List;

import com.erkobridee.agenda.dao.ContatoDAO;
import com.erkobridee.agenda.vo.Contato;
import com.erkobridee.util.interfaces.BasicCRUDInterface;

/**
 * Classe que disponibiliza o serviço AMF através do BlazeDS
 * 
 * @author Erko Bridee
 *
 */
public class ContatoService implements BasicCRUDInterface<Contato> {

	@Override
	public Contato get(Contato object) {
		return ContatoDAO.getInstance().get(object);
	}

	@Override
	public List<Contato> list() {
		return ContatoDAO.getInstance().list();
	}

	@Override
	public void remove(Contato object) {
		ContatoDAO.getInstance().remove(object);
	}

	@Override
	public void save(Contato object) throws Exception {
		ContatoDAO.getInstance().save(object);
	}

}
