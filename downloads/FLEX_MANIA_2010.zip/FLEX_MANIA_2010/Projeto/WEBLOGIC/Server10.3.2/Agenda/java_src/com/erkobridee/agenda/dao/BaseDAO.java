package com.erkobridee.agenda.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public abstract class BaseDAO {
	
	private static final String PERSISTENCE_UNIT = "agenda_db";
	
	/**
	 * Método que retorna um gerenciador de entidade instânciado
	 * 
	 * @return EntityManager
	 */
	protected EntityManager getEntityManager() {
		/*
		 *  criando um factory, pegando as configurações de acesso
		 *  a base de dados da aplicação 
		 */
		EntityManagerFactory entityManagerFactory = Persistence
		.createEntityManagerFactory(PERSISTENCE_UNIT);
		// retorna a instância do gerenciador de entidades
		return entityManagerFactory.createEntityManager();
	}
	
}
