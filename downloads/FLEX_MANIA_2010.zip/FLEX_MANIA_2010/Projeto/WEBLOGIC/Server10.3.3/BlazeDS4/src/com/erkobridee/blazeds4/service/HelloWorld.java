package com.erkobridee.blazeds4.service;

import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service("helloWorldService")
@RemotingDestination(channels={"my-amf"})
public class HelloWorld {

	@RemotingInclude
	public String sayHello(String name) {
		String out = "Hello, " + name + "\n";
		System.out.println(out);
		return out;
	}
	
}