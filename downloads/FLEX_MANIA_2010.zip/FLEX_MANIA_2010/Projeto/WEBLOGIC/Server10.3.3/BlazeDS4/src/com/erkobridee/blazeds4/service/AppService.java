package com.erkobridee.blazeds4.service;

import java.util.Date;

import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import com.erkobridee.blazeds4.vo.AppVO;

/**
 * @author Erko Bridee
 * 
 * @description
 * Classe que disponibiliza o servico chamado pela aplicacao flex
 *
 */
@Service("appService")
@RemotingDestination(channels={"my-amf"})
public class AppService {

	/**
	 * Recebe uma mensagem texto qualquer do Flex
	 * 
	 * @param msg String
	 */
	@RemotingInclude
	public void receivedHelloFromFlex( String msg ) {
		System.out.println( "Msg from flex: " + msg );
	}
	
	/**
	 * Recebe um objeto com atributos próprios
	 * 
	 * @param vo AppVO
	 */
	@RemotingInclude
	public void receivedVoFromFlex(AppVO vo) {
		System.out.println( vo );
	}
	
	/**
	 * Metodo que retorna uma mensagem de texto qualquer para o flex
	 * 
	 * @return String
	 */
	@RemotingInclude
	public String sayMessageToFlex() {
		return "Hello Flex, I'm BlazeDS. Nice to meet you.";
	}
	
	/**
	 * Metodo que retorna um objeto para o flex
	 * 
	 * @return AppVO
	 */
	@RemotingInclude
	public AppVO returnVoToFlex() {
		AppVO vo = new AppVO();
		vo.setMessage( this.sayMessageToFlex() );
		vo.setDtMessage( new Date() );
		return vo;
	}
	
	/**
	 * Metodo que responde a uma mensagem recebida do Flex no objeto
	 * 
	 * @param vo AppVO
	 * @return AppVO
	 */
	@RemotingInclude
	public AppVO answerVoToFlex(AppVO vo) {
		
		if( vo != null && vo.getMessage().trim().length() > 0 ) {
		
			String receivedMsg = vo.toString();			
			
			System.out.println(receivedMsg);
			
			vo = new AppVO();
			vo.setMessage( "OK Flex, I received your message here, follow: \n" + receivedMsg );
			vo.setDtMessage( new Date() );
			
		} else {
			vo = new AppVO();
			vo.setMessage( "Sorry Flex, I don't received any message here, could you send me again? Thank you." );
			vo.setDtMessage( new Date() );
		}
		
		return vo;
	}
	
}
